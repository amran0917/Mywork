int PrintHex(unsigned char, int);
