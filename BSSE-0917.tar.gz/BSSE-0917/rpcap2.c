#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include "HexDump02.h"

int data, i, PktLength;
 unsigned char *pkt,*mac, PacketData[2048];
 int count=0;
int numOfpack=0;
void packetDataOpCode(void);
void packetDataEthertype(void);
void printRecordHeader(void);
void printGlobalHeader(void);
void print_ver(void);
void print_use(char * binary);

void packetDataOpCode(void)
{
	for (i=0; i<24; i++)
	 {
    		data = getchar();
    		if (data == EOF ) {
     		 	putchar('\n');
      			return 0;
    		}
    		PacketData[i]=data & 0xFF;
  	}
 
 
  // Get PCAP Record Header*/
  while(1)
  {
  for (i=0; i<16; i++) {
    data = getchar();
    if (data == EOF ) {
    	
      putchar('\n');
      return 0;
    }
    PacketData[i]=data & 0xFF;
  }


  pkt = PacketData;
  PktLength = *((unsigned int *)(pkt+8) ); 


  // Get Packet 
  for (i=0; i<PktLength; i++) {
    	data = getchar();
    	if (data == EOF ) {
     	 putchar('\n');
      	return 0;
    	}
    	PacketData[i]=data & 0xFF;
  }
 
 	count++;
 	if(*(pkt+13)==06)
 	{
 	
 	 	
 	 	
  		printf("\n[000%d] Packet Data: \n",count);
  		//printf("\n");
  		pkt = PacketData;
  		 mac = PacketData;
  		for (i=0; i<PktLength; i++) {
   		 	PrintHex(*pkt++,i);
  		}
  		putchar("\n");
  		
  		 printf("\n\tARP Opcode: 0x"); 
			  	 
		 for (i=20; i<22; i++)
		  {
				 
			printf("%02X", *(mac+i));
			
		
	        }
			putchar('\n');  
          
          
           
          
  
  
     }
     
  }


}

void packetDataEthertype(void)
{

 for (i=0; i<24; i++) {
    data = getchar();
    if (data == EOF ) {
      putchar('\n');
      return 0;
    }
    PacketData[i]=data & 0xFF;
  }
 
 
  // Get PCAP Record Header*/
  while(1)
  {
  for (i=0; i<16; i++) {
    data = getchar();
    if (data == EOF ) {
    	
      putchar('\n');
      return 0;
    }
    PacketData[i]=data & 0xFF;
  }


  pkt = PacketData;
  PktLength = *((unsigned int *)(pkt+8) ); 


  // Get Packet 
  for (i=0; i<PktLength; i++) {
    	data = getchar();
    	if (data == EOF ) {
     	 putchar('\n');
      	return 0;
    	}
    	PacketData[i]=data & 0xFF;
  }
 
 	count++;
 	if(*(pkt+13)==06)
 	{
 	
 	 	
 	 	
  		printf("\n[000%d] Packet Data: \n",count);
  		//printf("\n");
  		pkt = PacketData;
  		 mac = PacketData;
  		for (i=0; i<PktLength; i++) {
   		 	PrintHex(*pkt++,i);
  		}
  		putchar("\n");
  		
  		 printf("\n\tEther Type: 0x"); 
			  	 
		 for (i=12; i<14; i++)
		  {
				 
			printf("%02X", *(mac+i));
			
		
	        }
			putchar('\n');  
          
          
           
          
  
  
     }
     
  }

}

void printRecordHeader(void)

{
  // Get PCAP Global Header
  for (i=0; i<24; i++) {
    data = getchar();
    if (data == EOF ) {
      putchar('\n');
      return 0;
    }
    PacketData[i]=data & 0xFF;
  }
 


  // Get PCAP Record Header*/
  while(1)
  {
  for (i=0; i<16; i++) {
    data = getchar();
    if (data == EOF ) {
    	
    	 printf("\n\n===================================================\n");	
    	
      putchar('\n');
      return 0;
    }
    PacketData[i]=data & 0xFF;
  }
 
 printf("\n[%04d] PCAP Record Header:\n",count+1);
  pkt = PacketData;
  for (i=0; i<16; i++) {
    PrintHex(*pkt++,i);
  }
  putchar('\n');
	
		count++;
		 
		
}
 


}

void printGlobalHeader(void)
{

  // Get PCAP Global Header
  for (i=0; i<24; i++) {
    data = getchar();
    if (data == EOF ) {
      putchar('\n');
      return 0;
    }
    PacketData[i]=data & 0xFF;
  }
 
  printf("\nPCAP Global Header:\n");
  pkt = PacketData;
  for (i=0; i<24; i++) {
    PrintHex(*pkt++,i);
  }
  putchar('\n');
  putchar('\n');
  printf("===================================================\n");


}

void print_ver(void) 
{


    fprintf(stderr,"Read PCAP File\nName: Amran Hossain, Roll: BSSE 0917\nInstitute of Information Technology\nUniversity of Dhaka, Dhaka, Bangladesh.\n$ Version: 3.0; Date: 2018/04/08 $\n");
    return;
}


void print_use(char * binary) 
{
    fprintf(stderr,"usage:\n\t%s [-ghprv]\n\n"
            "-g\t\tPrint PCAP Global Header Data\n"		    
		    "-h\t\tPrint this Help Message\n"
		    "-p 0\t\tPrint all Packet Data\n"
		    "-p 1\t\tPrint only ARP Packet Data\n"
   		    "-r\t\tPrint PCAP Record Header Data\n"
            "-v\t\tPrint Version\n",binary);            
    return;
}


int main(int argc, char ** argv) 
{
  int opt, index;
  int  ival=0,flagG=0,flagR=0;
  int flagA=0,flagE=0,flagP=0;
  
  char *cval, *strarg;
   // printf(argv[0]);
  if (argc == 1) {
    print_use(argv[0]);
    exit(1);
  }

  while ((opt = getopt(argc, argv, "vhrgp:")) != -1) {
    switch (opt) {
     case 'r':
        flagR = 1;
        break;
      case 'p':
        flagP = 1;
        ival = atoi(optarg);
        break;
      case 'g':
        flagG=1;
        break;
     
      case 'h':
        print_use(argv[0]);
        exit(0);
      case 'v':
        print_ver();
        exit(0);
      case ':':
        printf("option needs a value\n");
        print_use(argv[0]);
        exit(0);
      
      case '?':
      default :
        printf("unknown option: %c\n",optopt);
        print_use(argv[0]);
        exit(1);
    }
  }
 
 // strarg=argv[optind++];
  
  if (flagG == 1)
//    printf("\tPrint PCAP Global Header Data\n");
    printGlobalHeader();
    
  if (flagR == 1)
    //printf("\tPrint PCAP Record Header Data\n");

	printRecordHeader();

  if(flagP==1 && ival==0)
  {

     //   printf("\tPrint all Packet Data\n");
     packetDataEthertype();


  }
  if(flagP==1 && ival==1)
  {

       // printf("\tPrint only ARP Packet Data\n");
       
       packetDataOpCode();


  }
  
  if(flagE==1){
  
    printf("\tPrint Ethernet Header Data\n");
  }
  if(flagA==1){
  
    printf("\tPrint ARP Data\n");
    
  }
  






//printf ("\tFile name of the PCAP File is %s\n\n", strarg);

 for (index = optind; index < argc; index++)
    printf ("extra Non-option argument %s\n", argv[index]);

  exit(0);
}


/*
########################################################## End
*/

